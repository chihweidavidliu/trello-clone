(() => {
var exports = {};
exports.id = 767;
exports.ids = [767];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 1844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 6624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 5281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 7085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 9569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 7160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 2336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 7887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 8735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 8231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 3750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 9618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 8423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 1615:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport safe */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__.GlobalError),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(89);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3585);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5594);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    

    const tree = {
        children: [
        '',
        {
        children: [
        'app',
        {
        children: [
        'board',
        {
        children: [
        '[id]',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7813)), "/Users/David/projects/trello-clone/client/app/app/board/[id]/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7776)), "/Users/David/projects/trello-clone/client/app/app/layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7418))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5438)), "/Users/David/projects/trello-clone/client/app/layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7418))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["/Users/David/projects/trello-clone/client/app/app/board/[id]/page.tsx"];

    

    const originalPathname = "/app/board/[id]/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    

    // Create and export the route module that will be consumed.
    const options = {"definition":{"kind":"APP_PAGE","page":"/app/board/[id]/page","pathname":"/app/board/[id]","bundlePath":"app/app/board/[id]/page","filename":"","appPaths":[]}}
    const routeModule = new (next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default())({
      ...options,
      userland: {
        loaderTree: tree,
      },
    })
  

/***/ }),

/***/ 2986:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8763))

/***/ }),

/***/ 8763:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ BoardPageClient)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
;// CONCATENATED MODULE: ./helpers/insertAtIndex.ts
const insertAtIndex = (item, arr, index)=>{
    console.log("insert", {
        item,
        arr,
        index
    });
    const copy = [
        ...arr
    ];
    copy.splice(index, 0, item);
    return copy;
};

;// CONCATENATED MODULE: ./helpers/shiftInArray.ts
const shiftInArray = (arr, fromIndex, toIndex)=>{
    const copy = [
        ...arr
    ];
    const element = copy[fromIndex];
    copy.splice(fromIndex, 1);
    copy.splice(toIndex, 0, element);
    return copy;
};

;// CONCATENATED MODULE: ./components/Ticket.tsx
"use-client";

const TicketCard = ({ ticket, columnId })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        "data-column-id": columnId,
        className: "mt-3 border-2 border-gray-100 hover:bg-gray-200 rounded-md bg-white shadow-sm cursor-pointer p-3 min-h-[5rem]",
        draggable: true,
        id: ticket.id,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                className: "my-1 text-md select-none",
                children: ticket.title
            }),
            ticket.assignedTo && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                className: "my-1 text-sm select-none",
                children: [
                    "Assigned to: ",
                    ticket.assignedTo.fullname
                ]
            })
        ]
    });
};
/* harmony default export */ const Ticket = (TicketCard);

// EXTERNAL MODULE: ../node_modules/class-variance-authority/dist/index.mjs + 1 modules
var dist = __webpack_require__(6919);
;// CONCATENATED MODULE: ./components/Dropzone.tsx
"use-client";



const dropzone = (0,dist/* cva */.j)([
    "min-h-[5rem] rounded-md"
], {
    variants: {
        visible: {
            true: [
                "bg-gray-300",
                "mt-3"
            ]
        }
    }
});
const Dropzone = ({ children, id, handleDrop, isVisible })=>{
    const [isDragging, setIsDragging] = (0,react_.useState)(false);
    const wrapperRef = (0,react_.useRef)(null);
    const insertRef = (0,react_.useRef)(null);
    const shadowRef = (0,react_.useRef)(null);
    const dragCounterRef = (0,react_.useRef)(0); // cf https://stackoverflow.com/questions/50350406/dragleave-event-is-firing-on-inner-childs
    const cleanup = ()=>{
        // remove shadow and clear value for insertBefore
        insertRef.current = null;
        shadowRef?.current?.remove();
    };
    const onDragOver = (e)=>{
        e.preventDefault();
        const wrapperRect = wrapperRef.current?.getBoundingClientRect();
        if (!wrapperRect) return;
        // insert before if the mouse is closer to the top than the bottom of the dropzone element
        const insertBefore = e.clientY - wrapperRect.top < wrapperRect.bottom - e.clientY;
        if (insertRef.current === insertBefore) return;
        shadowRef.current?.remove();
        const shadow = document.createElement("div");
        shadow.className = `bg-gray-400 h-[5rem] my-3 rounded-md`;
        shadowRef.current = shadow;
        if (!insertBefore) {
            wrapperRef.current?.append(shadow);
        } else {
            wrapperRef.current?.prepend(shadow);
        }
        insertRef.current = insertBefore;
    };
    const onDrop = async (e)=>{
        e.preventDefault();
        const data = e.dataTransfer.getData("text");
        const draggedTicket = document.getElementById(data);
        if (!draggedTicket) return;
        console.log("draggedTicket", draggedTicket);
        // otherwise insert before/after the closest ticket in the list
        if (insertRef.current === null) return;
        if (!wrapperRef.current) return;
        const insertBefore = insertRef.current;
        if (insertBefore) {
            console.log("adding before");
            await handleDrop(draggedTicket.id, insertBefore);
        } else {
            console.log("adding after");
            await handleDrop(draggedTicket.id, insertBefore);
        }
        // tidy up
        cleanup();
    };
    const hideOriginalNode = (currentTarget)=>{
        setTimeout(function() {
            currentTarget.style.display = "none";
        }, 1);
    };
    const showOriginalNode = (currentTarget)=>{
        currentTarget.style.display = "revert";
    };
    const onDragStart = (e)=>{
        e.dataTransfer.setData("text", id);
        hideOriginalNode(e.currentTarget);
    };
    const onDragEnd = (e)=>{
        cleanup();
        showOriginalNode(e.currentTarget);
    };
    const onDragLeave = (e)=>{
        dragCounterRef.current--;
        if (dragCounterRef.current === 0) {
            console.log("leaving", id);
            setIsDragging(false);
            cleanup();
        }
    };
    const onDragEnter = (e)=>{
        console.log("entering", id);
        dragCounterRef.current++;
        // cleanup();
        setIsDragging(true);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: dropzone({
            visible: isVisible
        }),
        onDragEnter: onDragEnter,
        onDragLeave: onDragLeave,
        onDragOver: onDragOver,
        onDrop: onDrop,
        onDragStart: onDragStart,
        onDragEnd: onDragEnd,
        ref: wrapperRef,
        id: id,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "dropzone-contents",
            children: children
        })
    });
};
/* harmony default export */ const components_Dropzone = (Dropzone);

;// CONCATENATED MODULE: ./components/Column.tsx
"use-client";



const ColumnComponent = ({ column: { id, title, tickets }, handleTicketDrop })=>{
    const handleDrop = async (ticketId, newIndex)=>{
        if (ticketId.includes("placeholder")) {}
        // get ticket data
        return handleTicketDrop(ticketId, newIndex);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "width-[18rem] min-w-[18rem] max-w-[18rem] py-4 px-3 rounded-md border-2 border-slate-300 bg-slate-100 shadow-lg",
        id: id,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "text-lg text-blue-950 font-semibold",
                children: title
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "h-full",
                id: id + "-ticket-list",
                children: tickets.length > 0 ? tickets.sort((a, b)=>a.index - b.index).map((ticket, index)=>{
                    return /*#__PURE__*/ jsx_runtime_.jsx(components_Dropzone, {
                        id: ticket.id,
                        handleDrop: (ticketId, insertBefore)=>{
                            const ticketIndex = tickets.findIndex((t)=>t.id === ticketId);
                            const isPrecedingTicket = ticketIndex !== -1 && ticketIndex < index;
                            const newIndex = insertBefore || isPrecedingTicket ? index : index + 1;
                            return handleDrop(ticketId, newIndex);
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Ticket, {
                            ticket: ticket,
                            columnId: id
                        })
                    }, ticket.id);
                }) : /*#__PURE__*/ jsx_runtime_.jsx(components_Dropzone, {
                    id: id + "-placeholder-dropzone",
                    isVisible: true,
                    handleDrop: (ticketId, insertBefore)=>{
                        const newIndex = 0;
                        return handleDrop(ticketId, newIndex);
                    }
                })
            })
        ]
    });
};
/* harmony default export */ const Column = (ColumnComponent);

;// CONCATENATED MODULE: ./app/app/board/[id]/BoardPageClient.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 




function BoardPageClient({ initialColumns }) {
    const [columns, setColumns] = (0,react_.useState)(initialColumns);
    const ticketsById = columns.reduce((acc, col)=>{
        col.tickets.forEach((ticket)=>{
            acc[ticket.id] = ticket;
        });
        return acc;
    }, {});
    const handleTicketDrop = async (ticketId, indexInNewCol, newColId)=>{
        console.log("handling ticket drop", {
            ticketId,
            newColId,
            indexInNewCol
        });
        const updatedCols = columns.map((column)=>{
            const ticket = ticketsById[ticketId];
            if (ticket.columnId === newColId && column.id === ticket.columnId) {
                console.log("source col === target col", column);
                // this is the source col
                return {
                    ...column,
                    tickets: shiftInArray(column.tickets, ticket.index, indexInNewCol).map((t, index)=>({
                            ...t,
                            index
                        }))
                };
            } else if (ticket.columnId === column.id) {
                console.log("source col", column);
                // this is the source col
                return {
                    ...column,
                    tickets: column.tickets.filter((t)=>t.id !== ticket.id).map((t, index)=>({
                            ...t,
                            index
                        }))
                };
            } else if (newColId === column.id) {
                console.log("target col", column);
                // this is the target col
                return {
                    ...column,
                    tickets: insertAtIndex({
                        ...ticket,
                        columnId: newColId
                    }, column.tickets, indexInNewCol).map((t, index)=>({
                            ...t,
                            index
                        }))
                };
            }
            return column;
        });
        setColumns(updatedCols);
        console.log("updatedCols", updatedCols);
    };
    console.log("columns", columns);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "flex gap-1",
        children: columns.map((col)=>{
            return /*#__PURE__*/ jsx_runtime_.jsx(Column, {
                column: col,
                handleTicketDrop: (ticketId, indexInNewCol)=>handleTicketDrop(ticketId, indexInNewCol, col.id)
            }, col.id);
        })
    });
}


/***/ }),

/***/ 7813:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ BoardPage)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
;// CONCATENATED MODULE: ./app/mock-data.tsx
const users = {
    david: {
        id: "tewgge",
        email: "david@sourceful.com",
        fullname: "David Liu"
    },
    karlson: {
        id: "fbwrhwhe",
        email: "karlson@sourceful.com",
        fullname: "Karlson Lee"
    }
};
const backlogTickets = [
    {
        id: "1",
        title: "Fix Hero image alignment",
        index: 0,
        columnId: "backlog",
        assignedTo: users.karlson
    },
    {
        id: "2",
        title: "Add E2E test for ProductCard List",
        index: 1,
        columnId: "backlog",
        assignedTo: users.david
    },
    {
        id: "3",
        title: "Boff",
        index: 2,
        columnId: "backlog",
        assignedTo: users.karlson
    }
];
const backlogColumn = {
    id: "backlog",
    title: "Backlog",
    tickets: backlogTickets
};
const prioritisedTickets = [
    {
        id: "4",
        title: "Prioritised One",
        index: 0,
        columnId: "prioritised-for-sprint",
        assignedTo: users.karlson
    },
    {
        id: "5",
        title: "Prioritised Two",
        index: 1,
        columnId: "prioritised-for-sprint",
        assignedTo: users.david
    },
    {
        id: "6",
        title: "Prioritised Three",
        index: 2,
        columnId: "prioritised-for-sprint",
        assignedTo: users.karlson
    },
    {
        id: "7",
        title: "Prioritised Four",
        index: 3,
        columnId: "prioritised-for-sprint"
    }
];
const prioritisedForSprintColumn = {
    id: "prioritised-for-sprint",
    title: "Prioritised For Sprint",
    tickets: prioritisedTickets
};
const inProgressColumn = {
    id: "in-progress",
    title: "In Progress",
    tickets: []
};
const mockColumns = [
    backlogColumn,
    prioritisedForSprintColumn,
    inProgressColumn
];

// EXTERNAL MODULE: ../node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(1888);
;// CONCATENATED MODULE: ./app/app/board/[id]/BoardPageClient.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`/Users/David/projects/trello-clone/client/app/app/board/[id]/BoardPageClient.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const BoardPageClient = (__default__);
;// CONCATENATED MODULE: ./app/app/board/[id]/page.tsx



async function getBoardData(id) {
    // const res = await fetch("https://api.example.com/...");
    // // The return value is *not* serialized
    // // You can return Date, Map, Set, etc.
    // if (!res.ok) {
    //   // This will activate the closest `error.js` Error Boundary
    //   throw new Error("Failed to fetch data");
    // }
    // return res.json();
    return Promise.resolve(mockColumns);
}
async function BoardPage({ params }) {
    console.log("params", params);
    const columns = await getBoardData(params.id);
    console.log("columns", columns);
    return /*#__PURE__*/ jsx_runtime_.jsx(BoardPageClient, {
        initialColumns: columns || []
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [870,619,322,646,141,233], () => (__webpack_exec__(1615)));
module.exports = __webpack_exports__;

})();